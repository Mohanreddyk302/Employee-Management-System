import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import EmployeeLogin from './EmployeeLogin';
import AdminLogin from './AdminLogin';
import HomePage from './HomePage';
import EmployeeDashboard from './EmployeeDashboard'; // Import the EmployeeDashboard component
import AdminDashboard from './AdminDashboard'; // Import the AdminDashboard component

function App() {
  return (
    <Router>
      <div className="container-fluid">
        <Switch>
          <Route path="/" exact component={HomePage} />
          <Route path="/employee-login" component={EmployeeLogin} />
          <Route path="/admin-login" component={AdminLogin} />
          <Route path="/employee-dashboard" component={EmployeeDashboard} /> {/* Route for Employee Dashboard */}
          <Route path="/admin-dashboard" component={AdminDashboard} /> {/* Route for Admin Dashboard */}
        </Switch>
      </div>
    </Router>
  );
}

export default App;
