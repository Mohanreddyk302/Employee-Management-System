import React, { useState } from 'react';
import { useHistory } from 'react-router-dom'; // Import useHistory hook
import 'bootstrap/dist/css/bootstrap.min.css'; // Import Bootstrap CSS
import './styles.css'; // Import custom styles

const EmployeeLogin = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const history = useHistory(); // Initialize useHistory

  const handleLogin = () => {
    // Perform validation
    if (!username || !password) {
      setError('Please fill in all fields.');
      return;
    }
    
    // Simulated authentication logic
    if (username === 'employee' && password === 'password') {
      // Redirect to employee dashboard after successful login
      history.push('/employee-dashboard');
    } else {
      setError('Invalid username or password.');
    }
  };

  return (
    <div className="container">
      <h2>Employee Login</h2>
      <form>
        <div className="mb-3">
          <input
            type="text"
            className="form-control"
            placeholder="Username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
        </div>
        <div className="mb-3">
          <input
            type="password"
            className="form-control"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>
        <button type="button" className="btn btn-primary" onClick={handleLogin}>Login</button>
      </form>
      {error && <p className="error">{error}</p>}
    </div>
  );
};

export default EmployeeLogin;
