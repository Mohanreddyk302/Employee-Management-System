// EmployeeDashboard.js
import React from 'react';

const EmployeeDashboard = ({ username }) => {
  return (
    <div>
      <h2>Welcome, {username}!</h2>
      <p>This is your Employee Dashboard.</p>
      {/* Add employee-specific content here */}
    </div>
  );
};

export default EmployeeDashboard;