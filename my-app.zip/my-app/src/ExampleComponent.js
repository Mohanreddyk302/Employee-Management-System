ExampleComponent.js

import React from 'react';

const ExampleComponent = ({ onLogin }) => {
  const handleClick = () => {
    // Call the onLogin function when a button is clicked
    if (typeof onLogin === 'function') {
      onLogin();
    } else {
      console.error('onLogin is not a function');
    }
  };

  return (
    <div>
      <button onClick={handleClick}>Login</button>
    </div>
  );
};

export default ExampleComponent;
