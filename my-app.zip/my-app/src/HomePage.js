// HomePage.js

import React from 'react';
import { Link } from 'react-router-dom';
import './HomePage.css'; // Import your CSS file for HomePage styles

const HomePage = () => {
  return (
    <div className="homepage-container">
      <div className="jumbotron">
        <h1 className="display-4"><strong>Employee Management System</strong></h1> {/* Make the text bold */}
        <p className="lead">Welcome to our Employee Management System. Manage your employees efficiently.</p>
        <hr className="my-4" />
        <p>Sign in as:</p>
        <div className="btn-group" role="group" aria-label="Sign in buttons">
          <Link to="/employee-login" className="btn btn-primary">Employee</Link>
          <Link to="/admin-login" className="btn btn-secondary">Admin</Link>
        </div>
      </div>
    </div>
  );
}

export default HomePage;
