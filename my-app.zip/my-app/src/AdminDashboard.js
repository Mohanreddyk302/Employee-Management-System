// AdminDashboard.js
import React from 'react';

const AdminDashboard = ({ username }) => {
  return (
    <div>
      <h2>Welcome, {username}!</h2>
      <p>This is your Admin Dashboard.</p>
      {/* Add admin-specific content here */}
    </div>
  );
};

export default AdminDashboard;